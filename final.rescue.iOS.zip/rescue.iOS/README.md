# rescue 救援平台

請在 clone 之後的 rescue.iOS 目錄底下執行 pod install 安裝所需之檔案
或在 rescue.iOS 底下 取得 final.rescue.iOS.zip 另行解壓縮執行

